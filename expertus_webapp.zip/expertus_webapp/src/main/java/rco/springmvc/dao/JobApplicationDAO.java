package rco.springmvc.dao;

public interface JobApplicationDAO 
{
	void addJobApplication(String username, String refjob);
}
